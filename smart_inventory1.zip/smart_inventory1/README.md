# Smart Inventory and Sales Intelligence System
**BCA VI Semester Project 2025-26**
**Student:** Gangappa Shreekant Hegganni (U02AJ23S0414)
**Guide:** Smt. Kubra Shirur

---

## Project Structure
```
smart_inventory/
├── app.py                  # Main Flask app
├── requirements.txt        # Python dependencies
├── models/
│   └── __init__.py         # Database models (User, Product, Sale, etc.)
├── routes/
│   ├── auth.py             # Login / Logout
│   ├── dashboard.py        # Dashboard with charts
│   ├── inventory.py        # Product management (CRUD)
│   ├── sales.py            # Sales recording
│   └── reports.py          # Reports + AI demand prediction
├── utils/
│   └── seed.py             # Sample data loader
└── templates/
    ├── base.html           # Sidebar layout
    ├── login.html          # Login page
    ├── dashboard.html      # Main dashboard
    ├── inventory.html      # Product listing
    ├── add_product.html    # Add / Edit product
    ├── new_sale.html       # New sale with cart
    ├── sales.html          # Sales history
    ├── view_sale.html      # Invoice view
    └── reports.html        # Reports + AI predictions
```

---

## Setup Instructions

### 1. Install Python (3.10 or above)
Download from https://www.python.org/downloads/

### 2. Create Virtual Environment
```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the Application
```bash
python app.py
```

### 5. Open in Browser
Visit: http://127.0.0.1:5000

---

## Login Credentials

| Role  | Username | Password  |
|-------|----------|-----------|
| Admin | admin    | admin123  |
| Staff | staff1   | staff123  |

---

## Features
- Role-based login (Admin & Staff)
- Real-time inventory management
- Sales recording with cart system
- Low stock alerts
- Sales charts (daily, monthly)
- AI demand forecasting (Linear Regression via scikit-learn)
- Product performance reports

---

## Tech Stack
- **Backend:** Python 3, Flask
- **Database:** SQLite (via SQLAlchemy)
- **Frontend:** HTML5, CSS3, JavaScript, Chart.js
- **AI/ML:** scikit-learn (LinearRegression)
- **Auth:** Flask-Login, Flask-Bcrypt
