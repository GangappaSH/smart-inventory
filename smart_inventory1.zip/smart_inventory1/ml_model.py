import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

def get_historical_sales():
    """Fetch historical sales data from database"""
    from app import db, Sale, Product
    
    sales_data = db.session.query(
        Sale.sale_date,
        Sale.product_id,
        Product.name,
        Sale.quantity
    ).join(Product).all()
    
    df = pd.DataFrame([
        {
            'date': s.sale_date,
            'product_id': s.product_id,
            'product_name': s.name,
            'quantity': s.quantity
        } for s in sales_data
    ])
    
    if df.empty:
        return pd.DataFrame()
    
    df['date'] = pd.to_datetime(df['date']).dt.date
    df['day_of_week'] = pd.to_datetime(df['date']).dt.dayofweek
    df['month'] = pd.to_datetime(df['date']).dt.month
    
    return df.groupby(['product_id', 'product_name', 'date', 'day_of_week', 'month'])['quantity'].sum().reset_index()

def predict_demand():
    """AI-based demand prediction for next 7 days"""
    df = get_historical_sales()
    
    if len(df) < 10:  # Need minimum data
        return [{'product': 'Insufficient data', 'predicted': 0, 'days': 7}]
    
    predictions = []
    
    for product_id in df['product_id'].unique():
        product_data = df[df['product_id'] == product_id]
        
        if len(product_data) < 5:
            continue
            
        X = product_data[['day_of_week', 'month']]
        y = product_data['quantity']
        
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        model = LinearRegression()
        model.fit(X_scaled, y)
        
        # Predict next 7 days
        future_days = pd.date_range(start=datetime.now().date(), periods=7)
        future_features = np.array([[d.dayofweek, d.month] for d in future_days])
        future_scaled = scaler.transform(future_features)
        predicted = model.predict(future_scaled)
        
        avg_prediction = int(np.mean(predicted))
        product_name = product_data['product_name'].iloc[0]
        
        predictions.append({
            'product': product_name,
            'product_id': product_id,
            'predicted_next_7_days': avg_prediction,
            'confidence': min(95, 50 + len(product_data) * 5)
        })
    
    return sorted(predictions, key=lambda x: x['predicted_next_7_days'], reverse=True)[:5]