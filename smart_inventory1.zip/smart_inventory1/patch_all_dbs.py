import sqlite3
import os

db_paths = [
    'instance/inventory.db',
    'smart_inventory1/instance/inventory.db'
]

for db_path in db_paths:
    if os.path.exists(db_path):
        print(f"Connecting to {db_path}...")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Check users table
        cursor.execute("PRAGMA table_info(users)")
        cols = {row[1] for row in cursor.fetchall()}
        if 'phone' not in cols:
            print(f"Adding 'phone' to 'users' in {db_path}...")
            cursor.execute("ALTER TABLE users ADD COLUMN phone VARCHAR(20)")
        else:
            print(f"'phone' already exists in {db_path}/users.")

        # Check products table
        cursor.execute("PRAGMA table_info(products)")
        cols = {row[1] for row in cursor.fetchall()}
        if 'gst_rate' not in cols:
            print(f"Adding 'gst_rate' to 'products' in {db_path}...")
            cursor.execute("ALTER TABLE products ADD COLUMN gst_rate FLOAT DEFAULT 0.0")
        else:
            print(f"'gst_rate' already exists in {db_path}/products.")

        conn.commit()
        conn.close()
    else:
        print(f"Database {db_path} not found.")

print("Database patching finished.")
