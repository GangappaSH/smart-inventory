from app import create_app
from models import db
from sqlalchemy import text

app = create_app()
with app.app_context():
    conn = db.engine.connect()
    
    print("Checking 'users' table...")
    rows = conn.execute(text("PRAGMA table_info(users)")).fetchall()
    cols = {row[1] for row in rows}
    if 'phone' not in cols:
        print("Adding 'phone' column to 'users' table...")
        conn.execute(text("ALTER TABLE users ADD COLUMN phone VARCHAR(20)"))
        conn.commit()
    else:
        print("'phone' column already exists in 'users'.")

    print("Checking 'products' table...")
    rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
    cols = {row[1] for row in rows}
    if 'gst_rate' not in cols:
        print("Adding 'gst_rate' column to 'products' table...")
        conn.execute(text("ALTER TABLE products ADD COLUMN gst_rate FLOAT DEFAULT 0.0"))
        conn.commit()
    else:
        print("'gst_rate' column already exists in 'products'.")

    conn.close()
    print("Migration complete.")
