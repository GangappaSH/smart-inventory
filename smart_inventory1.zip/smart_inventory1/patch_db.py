import sqlite3
import os

db_path = 'instance/inventory.db'

if os.path.exists(db_path):
    print(f"Connecting to {db_path}...")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Check users table
    cursor.execute("PRAGMA table_info(users)")
    cols = {row[1] for row in cursor.fetchall()}
    if 'phone' not in cols:
        print("Adding 'phone' to 'users'...")
        cursor.execute("ALTER TABLE users ADD COLUMN phone VARCHAR(20)")
    else:
        print("'phone' already exists in 'users'.")

    # Check products table
    cursor.execute("PRAGMA table_info(products)")
    cols = {row[1] for row in cursor.fetchall()}
    if 'gst_rate' not in cols:
        print("Adding 'gst_rate' to 'products'...")
        cursor.execute("ALTER TABLE products ADD COLUMN gst_rate FLOAT DEFAULT 0.0")
    else:
        print("'gst_rate' already exists in 'products'.")

    conn.commit()
    conn.close()
    print("Database patching finished.")
else:
    print(f"Database {db_path} not found.")
